import num from '/static/es6/es6module.js';
window.__es6injected = num;
