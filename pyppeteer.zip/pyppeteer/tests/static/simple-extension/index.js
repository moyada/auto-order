// Mock script for background extension
